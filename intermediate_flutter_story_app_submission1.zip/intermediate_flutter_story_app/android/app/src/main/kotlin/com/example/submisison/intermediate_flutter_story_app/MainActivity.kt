package com.example.submisison.intermediate_flutter_story_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
