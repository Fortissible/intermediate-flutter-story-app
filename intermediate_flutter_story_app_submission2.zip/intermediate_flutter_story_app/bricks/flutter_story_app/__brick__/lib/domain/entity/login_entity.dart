class LoginEntity {
  String userId;
  String name;
  String token;

  LoginEntity({
    required this.userId,
    required this.name,
    required this.token,
  });
}